<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1729605455413'>
  <properties size='10'>
    <property name='org.eclipse.equinox.p2.cache' value='/Users/sita/.eclipse/1738435388_macosx_cocoa_aarch64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=macosx,osgi.arch=aarch64,osgi.ws=cocoa,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/Volumes/Eclipse Installer/Eclipse Installer.app/Contents/Eclipse'/>
    <property name='eclipse.touchpoint.launcherName' value='eclipse-inst'/>
    <property name='org.eclipse.equinox.p2.surrogate' value='true'/>
    <property name='org.eclipse.equinox.p2.cache.shared' value='/Volumes/Eclipse Installer/Eclipse Installer.app/Contents/Eclipse'/>
    <property name='org.eclipse.equinox.p2.configurationFolder' value='/Users/sita/.eclipse/1738435388_macosx_cocoa_aarch64/configuration'/>
    <property name='org.eclipse.equinox.p2.launcherConfiguration' value='/Users/sita/.eclipse/1738435388_macosx_cocoa_aarch64/configuration/eclipse.ini.ignored'/>
  </properties>
  <units size='4'>
    <unit id='SharedProfile_DefaultProfile' version='1.0.0.1725389801589' singleton='false' generation='2'>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.name' value='Shared profile'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='SharedProfile_DefaultProfile' version='1.0.0.1725389801589'/>
      </provides>
      <requires size='264'>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.jar&apos;, version(&apos;2.38.0.v20240721-0802&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.expressions&apos;, version(&apos;3.9.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.help&apos;, version(&apos;3.10.400.v20240415-0528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;1.5.300.v20240424-1301&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.installer.feature.group&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.cdatetime&apos;, version(&apos;1.5.0.202402011804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.event&apos;, version(&apos;1.7.100.v20240321-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.minimal.stripped&apos;, version(&apos;17.0.12.v20240802-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.orbit.xml-apis-ext&apos;, version(&apos;1.0.0.v20230923-0644&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.junit&apos;, version(&apos;1.4.0.v20240713-1033&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.shell&apos;, version(&apos;1.1.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.identity&apos;, version(&apos;3.10.0.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.di&apos;, version(&apos;1.5.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-beanutils&apos;, version(&apos;1.9.4&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.core&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2&apos;, version(&apos;1.17.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt&apos;, version(&apos;0.16.500.v20240727-1037&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-codec&apos;, version(&apos;1.16.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.urischeme&apos;, version(&apos;1.3.400.v20240606-1412&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.installer.product.with-jre.restricted.executable.cocoa.macosx.aarch64&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.operations&apos;, version(&apos;2.7.400.v20240425-0751&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.upnp&apos;, version(&apos;1.2.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher.cocoa.macosx.aarch64&apos;, version(&apos;1.2.1100.v20240722-2106&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.scr&apos;, version(&apos;2.2.12&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.tukaani.xz&apos;, version(&apos;1.10.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.jar&apos;, version(&apos;1.1.402.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.promise&apos;, version(&apos;1.3.0.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient5.feature.feature.group&apos;, version(&apos;1.1.702.v20240808-1900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.widgets.tablecombo&apos;, version(&apos;1.2.0.202402011804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.installer&apos;, version(&apos;1.34.0.v20240902-1207&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.oomph.setup.installer.product.with-jre.restricted.executable.cocoa.macosx.aarch64&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.annotation-api&apos;, version(&apos;2.1.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.simpleconfigurator.manipulator&apos;, version(&apos;2.3.300.v20240702-1335&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.position&apos;, version(&apos;1.0.1.201505202026&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.app&apos;, version(&apos;1.7.200.v20240722-2103&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher.eclipse&apos;, version(&apos;1.6.200.v20240812-2151&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.collections&apos;, version(&apos;3.2.2.v201511171945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director.app&apos;, version(&apos;1.3.400.v20240425-1316&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata&apos;, version(&apos;2.9.100.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository.tools&apos;, version(&apos;2.4.400.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.feature.group&apos;, version(&apos;1.31.0.v20240723-0951&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.logging&apos;, version(&apos;1.2.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf&apos;, version(&apos;3.11.0.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.client5.httpclient5&apos;, version(&apos;5.3.1.v20240126-0900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.cocoa.macosx.aarch64&apos;, version(&apos;1.2.1100.v20240722-2106&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.provisioning&apos;, version(&apos;1.2.0.201505202024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.concurrent&apos;, version(&apos;1.3.100.v20240514-0729&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.directorywatcher&apos;, version(&apos;1.4.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5&apos;, version(&apos;5.2.3.v20230922-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.garbagecollector&apos;, version(&apos;1.3.300.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.util&apos;, version(&apos;1.23.0.v20240713-1033&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore&apos;, version(&apos;2.37.0.v20240721-0802&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.text&apos;, version(&apos;3.14.100.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.cm&apos;, version(&apos;1.6.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;jakarta.inject.jakarta.inject-api&apos;, version(&apos;2.0.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.commands&apos;, version(&apos;3.12.200.v20240627-1019&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.runtime&apos;, version(&apos;1.1.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.group&apos;, version(&apos;1.7.300.v20240801-1024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;slf4j.api&apos;, version(&apos;2.0.16&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.group&apos;, version(&apos;3.14.1900.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.jreinfo&apos;, version(&apos;1.19.0.v20240520-1504&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.runtime&apos;, version(&apos;3.31.100.v20240524-2010&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.commons&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.group&apos;, version(&apos;2.23.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.jcraft.jsch&apos;, version(&apos;0.1.55.v20230916-1400&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jdt.core.compiler.batch&apos;, version(&apos;3.39.0.v20240820-0604&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi&apos;, version(&apos;3.21.0.v20240717-2103&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions.supplier&apos;, version(&apos;0.17.500.v20240419-1233&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.registry&apos;, version(&apos;3.12.100.v20240524-2011&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.text&apos;, version(&apos;3.25.200.v20240816-1151&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt&apos;, version(&apos;0.15.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.jobs&apos;, version(&apos;3.15.400.v20240619-0602&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.swt.theme&apos;, version(&apos;0.14.400.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.ui.questionnaire&apos;, version(&apos;1.13.0.v20220421-1218&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.event&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna&apos;, version(&apos;5.14.0.v20231211-1200&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.extensions&apos;, version(&apos;0.18.300.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage&apos;, version(&apos;1.2.0.v20210517-0327&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.net&apos;, version(&apos;1.5.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit&apos;, version(&apos;2.22.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.osgi.bundle.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.installer.feature.jar&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.useradmin&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.notifications&apos;, version(&apos;0.7.300.v20240707-1119&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.measurement&apos;, version(&apos;1.0.2.201802012109&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin.equinox&apos;, version(&apos;1.3.200.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.util&apos;, version(&apos;3.7.300.v20231104-1118&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.classic&apos;, version(&apos;1.5.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.group&apos;, version(&apos;1.6.2.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.constants&apos;, version(&apos;1.17.0.v20231215-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.macosx&apos;, version(&apos;1.102.300.v20240419-2334&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.aries.spifly.dynamic.bundle&apos;, version(&apos;1.3.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.extensionlocation&apos;, version(&apos;1.5.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.jarprocessor&apos;, version(&apos;1.3.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.feature.feature.jar&apos;, version(&apos;3.14.1900.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.feature.feature.jar&apos;, version(&apos;1.6.2.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.nebula.cwt&apos;, version(&apos;1.1.0.202402011804&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.renderers.swt.cocoa&apos;, version(&apos;0.14.400.v20240525-0701&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.engine&apos;, version(&apos;2.10.200.v20240425-1316&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui&apos;, version(&apos;2.8.500.v20240702-1335&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.jdom&apos;, version(&apos;1.1.3.v20230812-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui&apos;, version(&apos;2.23.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.feature.jar&apos;, version(&apos;2.22.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpclient&apos;, version(&apos;4.5.14&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.property&apos;, version(&apos;1.10.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclient5.feature.feature.jar&apos;, version(&apos;1.1.702.v20240808-1900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench&apos;, version(&apos;1.15.500.v20240730-1919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.feature.jar&apos;, version(&apos;2.26.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core.feature.feature.jar&apos;, version(&apos;1.7.300.v20240801-1024&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.preferences&apos;, version(&apos;3.11.100.v20240327-0645&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.director&apos;, version(&apos;2.6.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.base&apos;, version(&apos;1.18.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.artifact.repository&apos;, version(&apos;1.5.400.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mortbay.jasper.apache-jsp&apos;, version(&apos;9.0.90&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.natives&apos;, version(&apos;1.5.300.v20240423-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.mortbay.jasper.apache-el&apos;, version(&apos;9.0.90&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.ui&apos;, version(&apos;1.22.0.v20240510-1552&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.common&apos;, version(&apos;3.19.100.v20240524-2011&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.metatype&apos;, version(&apos;1.4.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.addons.swt&apos;, version(&apos;1.5.500.v20240620-1945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.jar&apos;, version(&apos;2.32.0.v20240731-0952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui.feature.group&apos;, version(&apos;2.26.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer&apos;, version(&apos;5.1.103.v20230705-0614&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di&apos;, version(&apos;1.9.500.v20240606-1236&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.ui.feature.group&apos;, version(&apos;2.22.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.core&apos;, version(&apos;1.5.500.v20240626-2102&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.doc&apos;, version(&apos;1.14.0.v20230618-0610&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.navigator&apos;, version(&apos;3.12.500.v20240620-1945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.touchpoint.eclipse&apos;, version(&apos;2.4.300.v20240511-1722&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.xml&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.group&apos;, version(&apos;4.33.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jsch.ui&apos;, version(&apos;1.5.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface&apos;, version(&apos;3.35.0.v20240820-2045&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.console&apos;, version(&apos;1.4.800.v20240513-1104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.sync&apos;, version(&apos;1.17.0.v20240317-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.edit&apos;, version(&apos;1.17.0.v20230204-0932&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.oomph.setup.installer.product.with-jre.restricted.configuration&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.feature.group&apos;, version(&apos;2.38.0.v20240721-0802&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.updatesite&apos;, version(&apos;1.3.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.edit&apos;, version(&apos;1.17.0.v20231119-1528&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.bindings&apos;, version(&apos;0.14.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.aarch64org.eclipse.core.runtime&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.group&apos;, version(&apos;4.33.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.beans&apos;, version(&apos;1.10.300.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.device&apos;, version(&apos;1.1.1.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.util.doc&apos;, version(&apos;1.14.0.v20230828-1517&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.util&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.ibm.icu&apos;, version(&apos;75.1.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench3&apos;, version(&apos;0.17.400.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.change&apos;, version(&apos;2.17.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.views&apos;, version(&apos;3.12.400.v20240620-1945&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.commons-io&apos;, version(&apos;2.16.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.widgets&apos;, version(&apos;1.4.200.v20240801-0837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.ssl.feature.feature.group&apos;, version(&apos;1.1.402.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcutil&apos;, version(&apos;1.78.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.model.workbench&apos;, version(&apos;2.4.300.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.commons.jxpath&apos;, version(&apos;1.3.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.services&apos;, version(&apos;2.4.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.ui&apos;, version(&apos;1.31.0.v20240723-0951&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.ui&apos;, version(&apos;2.24.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.ssl&apos;, version(&apos;1.3.100.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp&apos;, version(&apos;4.33.0.v20240903-0240&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp.feature.jar&apos;, version(&apos;4.33.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.equinox.launcher&apos;, version(&apos;1.6.900.v20240613-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.prefs&apos;, version(&apos;1.1.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.aarch64org.eclipse.equinox.common&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.workbench&apos;, version(&apos;3.133.0.v20240818-1923&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.bidi&apos;, version(&apos;1.5.100.v20240321-1445&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.di.annotations&apos;, version(&apos;1.8.400.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.component&apos;, version(&apos;1.5.1.202212101352&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.doc&apos;, version(&apos;1.14.0.v20230625-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filebuffers&apos;, version(&apos;3.8.300.v20240207-1054&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.repository&apos;, version(&apos;2.9.100.v20240511-1722&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.rcp.feature.jar&apos;, version(&apos;4.33.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree.analysis&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common&apos;, version(&apos;2.31.0.v20240731-0952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclientjava&apos;, version(&apos;2.0.300.v20240808-1900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.contexts&apos;, version(&apos;1.12.600.v20240413-1529&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.core&apos;, version(&apos;1.30.0.v20240723-0951&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.filesystem&apos;, version(&apos;1.11.0.v20240824-0952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.publisher&apos;, version(&apos;1.9.200.v20240429-0755&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup&apos;, version(&apos;1.29.0.v20240723-0951&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt&apos;, version(&apos;3.127.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.oomph.setup.installer.product.with-jre.restricted.application&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.core.commands&apos;, version(&apos;1.1.400.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.update.configurator&apos;, version(&apos;3.5.400.v20240416-0654&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.httpcore&apos;, version(&apos;4.4.16.v20221207-1049&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.css&apos;, version(&apos;1.17.0.v20231215-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jetty.servlet-api&apos;, version(&apos;4.0.6&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.jface.databinding&apos;, version(&apos;1.15.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer&apos;, version(&apos;3.3.0.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding&apos;, version(&apos;1.13.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.cocoa&apos;, version(&apos;1.3.200.v20240309-0857&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui&apos;, version(&apos;3.206.100.v20240720-1232&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.css.core&apos;, version(&apos;0.14.500.v20240606-0949&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.transport.ecf&apos;, version(&apos;1.4.300.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.edit.feature.jar&apos;, version(&apos;2.23.0.v20240604-0832&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.oomph.setup.installer.product.with-jre.restricted.ini.cocoa.macosx.aarch64&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.ide&apos;, version(&apos;3.17.200.v20231201-1637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.ssl&apos;, version(&apos;1.1.0.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.service.wireadmin&apos;, version(&apos;1.0.2.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.p2.edit&apos;, version(&apos;1.16.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.minimal.stripped.feature.group&apos;, version(&apos;17.0.12.v20240802-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.objectweb.asm.tree&apos;, version(&apos;9.7.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.core&apos;, version(&apos;2.12.100.v20240702-1335&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.frameworkadmin&apos;, version(&apos;2.3.200.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclientjava.feature.feature.group&apos;, version(&apos;2.0.200.v20240808-1900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingorg.eclipse.oomph.setup.installer.product.with-jre.restricted.config.cocoa.macosx.aarch64&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.osgi.compatibility.state&apos;, version(&apos;1.2.1000.v20240213-1057&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.jar&apos;, version(&apos;1.1.600.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.ui.sdk&apos;, version(&apos;1.3.300.v20240207-1113&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.net&apos;, version(&apos;1.5.500.v20240625-1706&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.dialogs&apos;, version(&apos;1.5.0.v20240424-0957&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.preferences&apos;, version(&apos;1.14.0.v20230617-1322&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.console&apos;, version(&apos;1.3.400.v20240321-1450&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.emf.xpath&apos;, version(&apos;0.4.300.v20240321-1245&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.ide&apos;, version(&apos;3.22.300.v20240828-1234&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.workbench.swt&apos;, version(&apos;0.17.500.v20240807-0911&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.p2.metadata.repository&apos;, version(&apos;1.5.400.v20240515-1919&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.databinding.observable&apos;, version(&apos;1.13.300.v20240424-0444&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.aarch64org.apache.felix.scr&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.i18n&apos;, version(&apos;1.17.0.v20231215-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage.oauth&apos;, version(&apos;1.1.0.v20190307-0457&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.common.feature.group&apos;, version(&apos;2.32.0.v20240731-0952&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher&apos;, version(&apos;1.6.900.v20240613-2009&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;toolingcocoa.macosx.aarch64org.eclipse.equinox.simpleconfigurator&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;com.sun.jna.platform&apos;, version(&apos;5.14.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.jreinfo.ui&apos;, version(&apos;1.16.0.v20240520-1504&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ui.forms&apos;, version(&apos;3.13.300.v20240424-0956&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.source.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.rcp_root&apos;, version(&apos;4.33.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;ch.qos.logback.core&apos;, version(&apos;1.5.7&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcprov&apos;, version(&apos;1.78.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.p2.feature.jar&apos;, version(&apos;1.31.0.v20240723-0951&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.installer.product.with-jre.restricted.executable.cocoa.macosx.aarch64.eclipse-inst&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security&apos;, version(&apos;1.4.400.v20240702-1702&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.emf.ecore.xmi&apos;, version(&apos;2.38.0.v20240721-0634&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.installer.product.with-jre.restricted&apos;, version(&apos;1.34.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.launcher.cocoa.macosx&apos;, version(&apos;1.2.1100.v20240722-2106&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.extractor.lib&apos;, version(&apos;1.9.0.v20220421-1218&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.swt.cocoa.macosx.aarch64&apos;, version(&apos;3.127.0.v20240903-0618&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.batik.util&apos;, version(&apos;1.17.0.v20231215-1130&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.osgi.util.function&apos;, version(&apos;1.2.0.202109301733&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.sat4j.pb&apos;, version(&apos;2.3.6.v20201214&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;bcpg&apos;, version(&apos;1.78.1&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.felix.gogo.command&apos;, version(&apos;1.1.2&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.xmlgraphics&apos;, version(&apos;2.9.0.v20230916-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.progress&apos;, version(&apos;0.4.600.v20240606-1020&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.minimal.stripped.feature.jar&apos;, version(&apos;17.0.12.v20240802-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.apache.httpcomponents.core5.httpcore5-h2&apos;, version(&apos;5.2.3.v20230922-1600&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.base.edit&apos;, version(&apos;1.18.0.v20240826-0747&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.provider.filetransfer.httpclient5&apos;, version(&apos;1.1.100.v20240808-1900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.userstorage.ui&apos;, version(&apos;1.1.0.v20190307-0457&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.core.ssl.feature.feature.group&apos;, version(&apos;1.1.600.v20240812-1535&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.ui&apos;, version(&apos;1.23.0.v20240826-0747&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.e4.ui.services&apos;, version(&apos;1.6.300.v20231201-1637&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.ecf.filetransfer.httpclientjava.feature.feature.jar&apos;, version(&apos;2.0.200.v20240808-1900&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.justj.openjdk.hotspot.jre.minimal.stripped.macosx.aarch64&apos;, version(&apos;17.0.12.v20240802-1518&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.core.contenttype&apos;, version(&apos;3.9.500.v20240708-0707&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.p2&apos;, version(&apos;1.21.0.v20240420-0837&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.equinox.security.ui&apos;, version(&apos;1.4.300.v20240513-1104&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;tooling.org.eclipse.update.feature.default&apos;, version(&apos;1.0.0&apos;)]' min='0'/>
        <required match='id == $0 &amp;&amp; version == $1' matchParameters='[&apos;org.eclipse.oomph.setup.core&apos;, version(&apos;1.31.0.v20240420-0837&apos;)]' min='0'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='org.eclipse.oomph.setup.installer.product.with-jre.restricted' version='1.34.0.v20240903-0618'>
      <update id='org.eclipse.oomph.setup.installer.product.with-jre.restricted' range='0.0.0' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse Installer'/>
        <property name='org.eclipse.equinox.p2.type.product' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='org.eclipse.oomph.p2.iu.compatibility' value='Major'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.installer.product.with-jre.restricted' version='1.34.0.v20240903-0618'/>
      </provides>
      <requires size='8'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.installer.feature.group' range='[1.34.0.v20240903-0618,1.34.0.v20240903-0618]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.justj.openjdk.hotspot.jre.minimal.stripped.feature.group' range='[17.0.12.v20240802-1518,17.0.12.v20240802-1518]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.oomph.setup.installer.product.with-jre.restricted.configuration' range='[1.34.0.v20240903-0618,1.34.0.v20240903-0618]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.oomph.setup.installer.product.with-jre.restricted.application' range='[1.34.0.v20240903-0618,1.34.0.v20240903-0618]'/>
        <required namespace='osgi.ee' name='JavaSE' range='0.0.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='configure'>
            setProgramProperty(propName:org.eclipse.ecf.provider.filetransfer.excludeContributors,propValue:org.eclipse.ecf.provider.filetransfer.httpclientjava);setProgramProperty(propName:eclipse.p2.max.threads,propValue:10);setProgramProperty(propName:oomph.p2.repository.retry,propValue:2);setProgramProperty(propName:org.eclipse.update.reconcile,propValue:false);setProgramProperty(propName:osgi.requiredJavaVersion,propValue:17.0);setProgramProperty(propName:p2.userAgent,propValue:eclipse/oomph/installer);setProgramProperty(propName:oomph.setup.product.catalog.filter,propValue:);setProgramProperty(propName:oomph.setup.product.filter,propValue:);setProgramProperty(propName:oomph.setup.product.version.filter,propValue:);setProgramProperty(propName:oomph.setup.jre.choice,propValue:true);
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:org.eclipse.ecf.provider.filetransfer.excludeContributors,propValue:);setProgramProperty(propName:eclipse.p2.max.threads,propValue:);setProgramProperty(propName:oomph.p2.repository.retry,propValue:);setProgramProperty(propName:org.eclipse.update.reconcile,propValue:);setProgramProperty(propName:osgi.requiredJavaVersion,propValue:);setProgramProperty(propName:p2.userAgent,propValue:);setProgramProperty(propName:oomph.setup.product.catalog.filter,propValue:);setProgramProperty(propName:oomph.setup.product.filter:);setProgramProperty(propName:oomph.setup.product.version.filter,propValue:);setProgramProperty(propName:oomph.setup.jre.choice,propValue:);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://eclipse.org/legal/epl/notice.php' url='http://eclipse.org/legal/epl/notice.php'>
          Eclipse Foundation Software User Agreement&#xA;&#xA;November 22, 2017&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION&#xA;AND/OR OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;). USE OF&#xA;THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS AGREEMENT AND/OR THE&#xA;TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW. BY USING THE CONTENT, YOU AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED&#xA;BY THIS AGREEMENT AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE&#xA;AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW. IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS OF ANY&#xA;APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED BELOW, THEN YOU&#xA;MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the Eclipse Foundation&#xA;is provided to you under the terms and conditions of the Eclipse Public License&#xA;Version 2.0 (&quot;EPL&quot;). A copy of the EPL is provided with this Content and is also&#xA;available at http://www.eclipse.org/legal/epl-2.0. For purposes of the EPL,&#xA;&quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code, documentation&#xA;and other files maintained in the Eclipse Foundation source code repository&#xA;(&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available as&#xA;downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;-   Content may be structured and packaged into modules to facilitate&#xA;    delivering, extending, and upgrading the Content. Typical modules may&#xA;    include plug-ins (&quot;Plug-ins&quot;), plug-in fragments (&quot;Fragments&quot;), and&#xA;    features (&quot;Features&quot;).&#xA;-   Each Plug-in or Fragment may be packaged as a sub-directory or JAR&#xA;    (Java™ ARchive) in a directory named &quot;plugins&quot;.&#xA;-   A Feature is a bundle of one or more Plug-ins and/or Fragments and&#xA;    associated material. Each Feature may be packaged as a sub-directory in a&#xA;    directory named &quot;features&quot;. Within a Feature, files named &quot;feature.xml&quot; may&#xA;    contain a list of the names and version numbers of the Plug-ins and/or&#xA;    Fragments associated with that Feature.&#xA;-   Features may also include other Features (&quot;Included Features&quot;). Within a&#xA;    Feature, files named &quot;feature.xml&quot; may contain a list of the names and&#xA;    version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be contained in&#xA;files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and conditions governing Features&#xA;and Included Features should be contained in files named &quot;license.html&quot;&#xA;(&quot;Feature Licenses&quot;). Abouts and Feature Licenses may be located in any&#xA;directory of a Download or Module including, but not limited to the following&#xA;locations:&#xA;&#xA;-   The top-level (root) directory&#xA;-   Plug-in and Fragment directories&#xA;-   Inside Plug-ins and Fragments packaged as JARs&#xA;-   Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;-   Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using&#xA;the Provisioning Technology (as defined below), you must agree to a license&#xA;(&quot;Feature Update License&quot;) during the installation process. If the Feature&#xA;contains Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform you&#xA;where you can locate them. Feature Update Licenses may be found in the &quot;license&quot;&#xA;property of files named &quot;feature.properties&quot; found within a Feature. Such&#xA;Abouts, Feature Licenses, and Feature Update Licenses contain the terms and&#xA;conditions (or references to such terms and conditions) that govern your use of&#xA;the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER TO THE EPL&#xA;OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS. SOME OF THESE&#xA;OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;-   Eclipse Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/epl-v10.html)&#xA;-   Eclipse Distribution License Version 1.0 (available at&#xA;    http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;-   Common Public License Version 1.0 (available at&#xA;    http://www.eclipse.org/legal/cpl-v10.html)&#xA;-   Apache Software License 1.1 (available at&#xA;    http://www.apache.org/licenses/LICENSE)&#xA;-   Apache Software License 2.0 (available at&#xA;    http://www.apache.org/licenses/LICENSE-2.0)&#xA;-   Mozilla Public License Version 1.1 (available at&#xA;    http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR TO&#xA;USE OF THE CONTENT. If no About, Feature License, or Feature Update License is&#xA;provided, please contact the Eclipse Foundation to determine what terms and&#xA;conditions govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which&#xA;include, but are not limited to, p2 and the Eclipse Update Manager&#xA;(&quot;Provisioning Technology&quot;) for the purpose of allowing users to install&#xA;software, documentation, information and/or other materials (collectively&#xA;&quot;Installable Software&quot;). This capability is provided with the intent of allowing&#xA;such users to install, extend and update Eclipse-based products. Information&#xA;about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install&#xA;Installable Software. You shall be responsible for enabling the applicable&#xA;license agreements relating to the Installable Software to be presented to, and&#xA;accepted by, the users of the Provisioning Technology in accordance with the&#xA;Specification. By using Provisioning Technology in such a manner and making it&#xA;available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the&#xA;following:&#xA;&#xA;1.  A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may&#xA;    execute the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the&#xA;    intent of installing, extending or updating the functionality of an&#xA;    Eclipse-based product.&#xA;2.  During the Provisioning Process, the Provisioning Technology may cause third&#xA;    party Installable Software or a portion thereof to be accessed and copied to&#xA;    the Target Machine.&#xA;3.  Pursuant to the Specification, you will provide to the user the terms and&#xA;    conditions that govern the use of the Installable Software (&quot;Installable&#xA;    Software Agreement&quot;) and such Installable Software Agreement shall be&#xA;    accessed from the Target Machine in accordance with the Specification. Such&#xA;    Installable Software Agreement must inform the user of the terms and&#xA;    conditions that govern the Installable Software and must solicit acceptance&#xA;    by the end user in the manner prescribed in such Installable&#xA;    Software Agreement. Upon such indication of agreement by the user, the&#xA;    provisioning Technology will complete installation of the&#xA;    Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are currently&#xA;may have restrictions on the import, possession, and use, and/or re-export to&#xA;another country, of encryption software. BEFORE using any encryption software,&#xA;please check the country&apos;s laws, regulations and policies concerning the import,&#xA;possession, or use, and re-export of encryption software, to see if this is&#xA;permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the&#xA;United States, other countries, or both.
        </license>
      </licenses>
    </unit>
    <unit id='org.eclipse.oomph.setup.installer.product.with-jre.restricted.executable.cocoa.macosx.aarch64' version='1.34.0.v20240903-0618'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.oomph.setup.installer.product.with-jre.restricted.executable.cocoa.macosx.aarch64' version='1.34.0.v20240903-0618'/>
        <provided namespace='toolingorg.eclipse.oomph.setup.installer.product.with-jre.restricted' name='org.eclipse.oomph.setup.installer.product.with-jre.restricted.executable' version='1.34.0.v20240903-0618'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx' range='0.0.0'>
          <filter>
            (&amp;(osgi.arch=aarch64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
      </requires>
      <filter>
        (&amp;(osgi.arch=aarch64)(osgi.os=macosx)(osgi.ws=cocoa))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.oomph.setup.installer.product.with-jre.restricted.executable.cocoa.macosx.aarch64' version='1.34.0.v20240903-0618'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='org.eclipse.rcp_root' version='4.33.0.v20240903-0618'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' version='4.33.0.v20240903-0618'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp_root' version='4.33.0.v20240903-0618'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='4'>
    <iuProperties id='SharedProfile_DefaultProfile' version='1.0.0.1725389801589'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.oomph.setup.installer.product.with-jre.restricted' version='1.34.0.v20240903-0618'>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.oomph.setup.installer.product.with-jre.restricted.executable.cocoa.macosx.aarch64' version='1.34.0.v20240903-0618'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/macosx/cocoa/aarch64/Eclipse Installer.app/Contents/Eclipse/../' value='/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/macosx/cocoa/aarch64/Eclipse Installer.app/Contents/Resources|/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/macosx/cocoa/aarch64/Eclipse Installer.app/Contents/Resources/eclipse-inst.icns|/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/macosx/cocoa/aarch64/Eclipse Installer.app/Contents/MacOS|/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/macosx/cocoa/aarch64/Eclipse Installer.app/Contents/MacOS/eclipse-inst|/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/macosx/cocoa/aarch64/Eclipse Installer.app/Contents/Info.plist|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp_root' version='4.33.0.v20240903-0618'>
      <properties size='3'>
        <property name='unzipped|@artifact|/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/macosx/cocoa/aarch64/Eclipse Installer.app/Contents/Eclipse' value='/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/macosx/cocoa/aarch64/Eclipse Installer.app/Contents/Eclipse/readme|/home/jenkins/agent/workspace/build_master/products/org.eclipse.oomph.setup.installer.product/target/products/org.eclipse.oomph.setup.installer.product.with-jre.restricted/macosx/cocoa/aarch64/Eclipse Installer.app/Contents/Eclipse/readme/readme_eclipse.html|'/>
        <property name='org.eclipse.equinox.p2.type.lock' value='3'/>
        <property name='org.eclipse.equinox.p2.base' value='true'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
