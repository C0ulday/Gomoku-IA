<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='_Users_sita_eclipse_java-2024-092_Eclipse.app_Contents_Eclipse' timestamp='1729605475931'>
  <properties size='7'>
    <property name='org.eclipse.equinox.p2.cache' value='/Users/sita/.p2/pool'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=macosx,osgi.arch=aarch64,osgi.ws=cocoa'/>
    <property name='org.eclipse.oomph.p2.profile.type' value='Installation'/>
    <property name='org.eclipse.oomph.p2.profile.shared.pool' value='true'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/Users/sita/eclipse/java-2024-092/Eclipse.app/Contents/Eclipse'/>
  </properties>
</profile>
